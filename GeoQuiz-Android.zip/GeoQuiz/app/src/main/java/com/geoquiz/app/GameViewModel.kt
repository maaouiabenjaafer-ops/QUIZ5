package com.geoquiz.app

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.geoquiz.app.data.Country
import com.geoquiz.app.data.countries

enum class QuizMode { FLAG_TO_NAME, CAPITAL_TO_NAME }

data class Question(
    val prompt: String,
    val options: List<Country>,
    val correctIndex: Int
)

class GameViewModel : ViewModel() {

    private var mode: QuizMode = QuizMode.FLAG_TO_NAME

    val currentIndex = mutableStateOf(0)
    val score = mutableStateOf(0)
    val questions = mutableStateOf<List<Question>>(emptyList())
    val answered = mutableStateOf(false)
    val selectedIndex = mutableStateOf(-1)

    fun startQuiz(quizMode: QuizMode, questionCount: Int = 10) {
        mode = quizMode
        val pool = countries.shuffled().take(questionCount)
        questions.value = pool.map { correct -> buildQuestion(correct) }
        currentIndex.value = 0
        score.value = 0
        answered.value = false
        selectedIndex.value = -1
    }

    private fun buildQuestion(correct: Country): Question {
        val wrongOptions = countries.filter { it != correct }.shuffled().take(3)
        val options = (wrongOptions + correct).shuffled()
        val correctIndex = options.indexOf(correct)
        val prompt = when (mode) {
            QuizMode.FLAG_TO_NAME -> correct.flag
            QuizMode.CAPITAL_TO_NAME -> correct.capital
        }
        return Question(prompt, options, correctIndex)
    }

    fun selectAnswer(index: Int) {
        if (answered.value) return
        answered.value = true
        selectedIndex.value = index
        if (index == questions.value[currentIndex.value].correctIndex) {
            score.value += 1
        }
    }

    /** Returns true if it moved to a next question, false if the quiz is over. */
    fun nextQuestion(): Boolean {
        return if (currentIndex.value < questions.value.size - 1) {
            currentIndex.value += 1
            answered.value = false
            selectedIndex.value = -1
            true
        } else {
            false
        }
    }

    fun isLastQuestion() = currentIndex.value == questions.value.size - 1
}
