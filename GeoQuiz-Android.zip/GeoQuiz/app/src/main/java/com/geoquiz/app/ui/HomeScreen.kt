package com.geoquiz.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(onStage1Click: () -> Unit, onStage2Click: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🌍 لعبة الجغرافيا", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Text("اختبر معلوماتك عن دول العالم", fontSize = 14.sp)
        Spacer(modifier = Modifier.height(48.dp))

        Button(onClick = onStage1Click, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("المرحلة 1: الدول والأعلام 🏳️", fontSize = 18.sp)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onStage2Click, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("المرحلة 2: العواصم والدول 🏛️", fontSize = 18.sp)
        }
    }
}
