package com.geoquiz.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ResultScreen(score: Int, total: Int, onHomeClick: () -> Unit) {
    val percentage = if (total > 0) (score * 100 / total) else 0
    val message = when {
        percentage >= 80 -> "ممتاز! 🏆"
        percentage >= 50 -> "جيد جدًا! 👍"
        else -> "حاول مرة أخرى 💪"
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(message, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(24.dp))
        Text("نتيجتك: $score من $total", fontSize = 20.sp)
        Spacer(modifier = Modifier.height(48.dp))
        Button(onClick = onHomeClick, modifier = Modifier.fillMaxWidth().height(50.dp)) {
            Text("العودة للقائمة الرئيسية")
        }
    }
}
