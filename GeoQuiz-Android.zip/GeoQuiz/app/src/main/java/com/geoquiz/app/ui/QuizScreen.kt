package com.geoquiz.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.geoquiz.app.GameViewModel

@Composable
fun QuizScreen(viewModel: GameViewModel, stageTitle: String, onFinished: () -> Unit) {
    val questions = viewModel.questions.value
    if (questions.isEmpty()) return

    val index = viewModel.currentIndex.value
    val question = questions[index]
    val answered = viewModel.answered.value
    val selected = viewModel.selectedIndex.value

    Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
        Text(stageTitle, fontSize = 16.sp, color = Color.Gray)
        Text("السؤال ${index + 1} من ${questions.size}", fontSize = 14.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(8.dp))
        Text("النقاط: ${viewModel.score.value}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(24.dp))

        Box(
            modifier = Modifier.fillMaxWidth().height(120.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(question.prompt, fontSize = 52.sp, textAlign = TextAlign.Center)
        }

        Spacer(modifier = Modifier.height(24.dp))

        question.options.forEachIndexed { i, option ->
            val bgColor = when {
                !answered -> MaterialTheme.colorScheme.primary
                i == question.correctIndex -> Color(0xFF4CAF50)
                i == selected -> Color(0xFFF44336)
                else -> MaterialTheme.colorScheme.primary
            }
            Button(
                onClick = { viewModel.selectAnswer(i) },
                enabled = !answered,
                colors = ButtonDefaults.buttonColors(containerColor = bgColor),
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            ) {
                Text(option.name, fontSize = 16.sp)
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        if (answered) {
            val lastQuestion = viewModel.isLastQuestion()
            Button(
                onClick = {
                    val hasNext = viewModel.nextQuestion()
                    if (!hasNext) onFinished()
                },
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text(if (lastQuestion) "إنهاء" else "السؤال التالي")
            }
        }
    }
}
